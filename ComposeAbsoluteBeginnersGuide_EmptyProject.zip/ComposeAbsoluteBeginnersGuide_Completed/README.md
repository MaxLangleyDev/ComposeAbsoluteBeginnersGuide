# ComposeAbsoluteBeginnersGuide

This is a simple Compose Multiplatform project used to demonstrate the fundamentals of Jetpack Compose.
